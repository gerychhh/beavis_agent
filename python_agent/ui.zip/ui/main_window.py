from __future__ import annotations

import json

from PySide6.QtCore import QEasingCurve, QPropertyAnimation, Qt, Signal, Slot
from PySide6.QtGui import QKeySequence, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QGraphicsOpacityEffect,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QScrollArea,
    QSizePolicy,
    QStyle,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
    QKeySequenceEdit,
)

from python_agent.core.schemas import PipelineOutput
from python_agent.ui.formatting import error_to_json, output_summary, output_title, output_to_json
from python_agent.ui.history_store import CommandHistoryStore, HistoryEntry
from python_agent.ui.icons import BEAVIS_LOGO_PATH, beavis_icon
from python_agent.ui.settings_store import UiSettings
from python_agent.ui.workers import CommandRunner, UserAppRunner
from python_agent.resolvers.app_catalog_overrides import load_app_catalog_overrides
from python_agent.resolvers.user_app_catalog import suggest_app_id
from python_agent.training.generate_open_app_dataset import APP_CATALOG as BUILTIN_APP_CATALOG
from python_agent.voice.audio import list_input_devices
from python_agent.voice.settings import (
    STT_COMPUTE_CHOICES,
    STT_DEVICE_CHOICES,
    STT_MODEL_CHOICES,
    SttSettings,
    VadSettings,
    VoiceSettings,
)


class BeavisMainWindow(QMainWindow):
    hotkey_settings_changed = Signal(bool, str)
    settings_changed = Signal(object)
    voice_test_requested = Signal()

    def __init__(
        self,
        runner: CommandRunner,
        user_app_runner: UserAppRunner | None = None,
        history_store: CommandHistoryStore | None = None,
        settings: UiSettings | None = None,
        hotkey_locked: bool = False,
        autoload: bool = True,
    ) -> None:
        super().__init__()
        self.runner = runner
        self.user_app_runner = user_app_runner or UserAppRunner()
        self.history_store = history_store or CommandHistoryStore()
        self.settings = settings or UiSettings()
        self.hotkey_locked = hotkey_locked
        self.history_entries: list[HistoryEntry] = []
        self._animations: list[QPropertyAnimation] = []
        self._app_id_user_changed = False
        self._windows_apps: list[dict[str, str]] = []
        self._selected_windows_app: dict[str, str] | None = None
        self._user_apps: list[dict[str, object]] = []
        self._selected_user_app: dict[str, object] | None = None
        self._app_form_mode = "new"
        self._active_app_dialog: QDialog | None = None
        self._last_user_app_action = ""

        self.setWindowTitle("Beavis Agent")
        self.setWindowIcon(beavis_icon())
        self.resize(1100, 740)
        self.setMinimumSize(760, 480)

        self._build_ui()
        self._wire_runner()
        if autoload:
            self._load_windows_apps()
            self._load_user_apps()
        self._apply_style()
        self.refresh_history()

    def _build_ui(self) -> None:
        self.command_input = QLineEdit(self)
        self.command_input.setPlaceholderText("Введите команду")
        self.command_input.returnPressed.connect(self._submit)

        self.execute_checkbox = QCheckBox("Выполнять", self)
        self.execute_checkbox.setChecked(True)

        self.run_button = QPushButton("Запустить", self)
        self.run_button.setProperty("kind", "primary")
        self.run_button.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPlay))
        self.run_button.clicked.connect(self._submit)

        self.status_label = QLabel("Готов", self)
        self.status_label.setObjectName("statusLabel")
        self.status_label.setProperty("state", "idle")
        self.status_effect = QGraphicsOpacityEffect(self.status_label)
        self.status_effect.setOpacity(1.0)
        self.status_label.setGraphicsEffect(self.status_effect)

        self.summary_view = QPlainTextEdit(self)
        self.summary_view.setObjectName("summaryView")
        self.summary_view.setReadOnly(True)
        self.summary_view.setMaximumHeight(132)
        self.summary_view.setPlainText("Команд ещё не было")

        self.json_view = QPlainTextEdit(self)
        self.json_view.setObjectName("jsonView")
        self.json_view.setReadOnly(True)
        self.json_view.setMinimumHeight(320)
        self.json_view.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        self.tabs = QTabWidget(self)
        self.tabs.setObjectName("mainTabs")
        self.tabs.addTab(self._scrollable_tab(self._build_command_tab()), "Главная")
        self.tabs.addTab(self._scrollable_tab(self._build_apps_tab_v2()), "Приложения")
        self.tabs.addTab(self._scrollable_tab(self._build_history_tab()), "История")
        self.tabs.addTab(self._scrollable_tab(self._build_settings_tab()), "Настройки")

        root = QVBoxLayout()
        root.setContentsMargins(24, 22, 24, 24)
        root.setSpacing(16)
        root.addWidget(self._build_header())
        root.addWidget(self.tabs, 1)

        central = QWidget(self)
        central.setObjectName("appRoot")
        central.setLayout(root)
        self.setCentralWidget(central)

    def _build_header(self) -> QWidget:
        logo = QLabel(self)
        logo.setObjectName("logo")
        pixmap = QPixmap(str(BEAVIS_LOGO_PATH))
        if not pixmap.isNull():
            logo.setPixmap(
                pixmap.scaled(
                    46,
                    46,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
        logo.setFixedSize(52, 52)

        title = QLabel("Beavis Agent", self)
        title.setObjectName("titleLabel")
        subtitle = QLabel("Локальный ассистент Windows", self)
        subtitle.setObjectName("subtitleLabel")

        title_col = QVBoxLayout()
        title_col.setSpacing(2)
        title_col.addWidget(title)
        title_col.addWidget(subtitle)

        header = QFrame(self)
        header.setObjectName("headerPanel")
        layout = QHBoxLayout(header)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(14)
        layout.addWidget(logo)
        layout.addLayout(title_col, 1)
        layout.addWidget(self.status_label)
        return header

    def _scrollable_tab(self, content: QWidget) -> QScrollArea:
        content.setMinimumWidth(760)
        content.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        scroll = QScrollArea(self)
        scroll.setObjectName("tabScrollArea")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setWidget(content)
        return scroll

    def _build_command_tab(self) -> QWidget:
        input_panel = QFrame(self)
        input_panel.setObjectName("glassPanel")

        input_row = QHBoxLayout()
        input_row.setSpacing(12)
        input_row.addWidget(self.command_input, 1)
        input_row.addWidget(self.execute_checkbox)
        input_row.addWidget(self.run_button)

        input_layout = QVBoxLayout(input_panel)
        input_layout.setContentsMargins(18, 18, 18, 18)
        input_layout.addLayout(input_row)

        voice_panel = QFrame(self)
        voice_panel.setObjectName("glassPanel")
        self.voice_status_label = QLabel("Голос по hotkey", self)
        self.voice_status_label.setObjectName("sectionTitle")
        self.voice_detail_label = QLabel("Ctrl+Alt+V слушает короткую команду без имени агента", self)
        self.voice_detail_label.setObjectName("hintLabel")
        self.voice_level = QProgressBar(self)
        self.voice_level.setRange(0, 100)
        self.voice_level.setValue(0)
        self.voice_level.setTextVisible(False)
        voice_layout = QVBoxLayout(voice_panel)
        voice_layout.setContentsMargins(18, 14, 18, 14)
        voice_layout.setSpacing(8)
        voice_layout.addWidget(self.voice_status_label)
        voice_layout.addWidget(self.voice_detail_label)
        voice_layout.addWidget(self.voice_level)

        result_panel = QFrame(self)
        result_panel.setObjectName("glassPanel")

        result_layout = QVBoxLayout(result_panel)
        result_layout.setContentsMargins(18, 16, 18, 18)
        result_layout.setSpacing(10)
        result_layout.addWidget(QLabel("Сводка", self))
        result_layout.addWidget(self.summary_view)
        result_layout.addWidget(QLabel("JSON", self))
        result_layout.addWidget(self.json_view, 1)

        tab = QWidget(self)
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(0, 14, 0, 0)
        layout.setSpacing(14)
        layout.addWidget(input_panel)
        layout.addWidget(voice_panel)
        layout.addWidget(result_panel, 1)
        return tab

    def _build_history_tab(self) -> QWidget:
        self.history_table = QTableWidget(self)
        self.history_table.setObjectName("historyTable")
        self.history_table.setColumnCount(8)
        self.history_table.setHorizontalHeaderLabels(
            ["Время", "Источник", "Команда", "Skill", "Args", "Confidence", "Результат", "Оценка"]
        )
        self.history_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.history_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.history_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.history_table.verticalHeader().setVisible(False)
        self.history_table.horizontalHeader().setStretchLastSection(False)
        self.history_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.history_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.history_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.history_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.history_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.history_table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        self.history_table.horizontalHeader().setSectionResizeMode(6, QHeaderView.ResizeMode.Stretch)
        self.history_table.horizontalHeader().setSectionResizeMode(7, QHeaderView.ResizeMode.ResizeToContents)
        self.history_table.setFixedHeight(340)
        self.history_table.itemSelectionChanged.connect(self._show_selected_history)

        self.history_detail = QPlainTextEdit(self)
        self.history_detail.setObjectName("jsonView")
        self.history_detail.setReadOnly(True)
        self.history_detail.setFixedHeight(170)

        self.mark_correct_button = QPushButton("Верно", self)
        self.mark_correct_button.setProperty("kind", "positive")
        self.mark_correct_button.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_DialogApplyButton))
        self.mark_correct_button.clicked.connect(lambda: self._mark_selected_history("correct"))

        self.mark_incorrect_button = QPushButton("Ошибка", self)
        self.mark_incorrect_button.setProperty("kind", "warning")
        self.mark_incorrect_button.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MessageBoxWarning))
        self.mark_incorrect_button.clicked.connect(lambda: self._mark_selected_history("incorrect"))

        refresh_button = QPushButton("Обновить", self)
        refresh_button.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_BrowserReload))
        refresh_button.clicked.connect(self.refresh_history)

        toolbar = QHBoxLayout()
        toolbar.setSpacing(10)
        toolbar.addWidget(self.mark_correct_button)
        toolbar.addWidget(self.mark_incorrect_button)
        toolbar.addStretch(1)
        toolbar.addWidget(refresh_button)

        panel = QFrame(self)
        panel.setObjectName("glassPanel")
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(18, 16, 18, 18)
        panel_layout.setSpacing(12)
        panel_layout.addLayout(toolbar)
        panel_layout.addWidget(self.history_table, 1)
        panel_layout.addWidget(self.history_detail)

        tab = QWidget(self)
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(0, 14, 0, 0)
        layout.addWidget(panel, 1)
        return tab

    def _build_apps_tab(self) -> QWidget:
        self.app_path_input = QLineEdit(self)
        self.app_path_input.setPlaceholderText(r"D:\Tools\App\app.exe")
        self.app_path_input.textChanged.connect(self._update_suggested_app_id)

        browse_button = QPushButton("Выбрать", self)
        browse_button.clicked.connect(self._browse_app_path)

        self.app_display_name_input = QLineEdit(self)
        self.app_display_name_input.setPlaceholderText("Название приложения")
        self.app_display_name_input.textChanged.connect(self._update_suggested_app_id)

        self.app_id_input = QLineEdit(self)
        self.app_id_input.setPlaceholderText("app_id")
        self.app_id_input.textEdited.connect(self._mark_app_id_changed)
        self.app_id_input.textChanged.connect(self._validate_app_form)
        self.app_id_input.textChanged.connect(self._validate_app_form)

        self.app_speech_forms_input = QPlainTextEdit(self)
        self.app_speech_forms_input.setObjectName("summaryView")
        self.app_speech_forms_input.setPlaceholderText("Сленговые названия, по одному на строку")
        self.app_speech_forms_input.setMaximumHeight(116)

        self.add_app_button = QPushButton("Добавить и обучить", self)
        self.add_app_button.setProperty("kind", "primary")
        self.add_app_button.clicked.connect(self._submit_user_app)

        self.update_app_button = QPushButton("Сохранить сленг и обучить", self)
        self.update_app_button.clicked.connect(self._submit_update_user_app)
        self.update_app_button.setEnabled(False)

        self.delete_app_button = QPushButton("Удалить и обучить", self)
        self.delete_app_button.setProperty("kind", "warning")
        self.delete_app_button.clicked.connect(self._submit_delete_user_app)
        self.delete_app_button.setEnabled(False)

        self.app_progress_view = QPlainTextEdit(self)
        self.app_progress_view.setObjectName("jsonView")
        self.app_progress_view.setReadOnly(True)
        self.app_progress_view.setPlainText("Готов добавить приложение")

        self.user_apps_table = QTableWidget(self)
        self.user_apps_table.setObjectName("historyTable")
        self.user_apps_table.setColumnCount(4)
        self.user_apps_table.setHorizontalHeaderLabels(["Название", "app_id", "Тип", "Сленг"])
        self.user_apps_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.user_apps_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.user_apps_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.user_apps_table.verticalHeader().setVisible(False)
        self.user_apps_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.user_apps_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.user_apps_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.user_apps_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.user_apps_table.itemSelectionChanged.connect(self._select_user_app)

        refresh_user_apps_button = QPushButton("Обновить добавленные", self)
        refresh_user_apps_button.clicked.connect(self._load_user_apps)

        form = QGridLayout()
        form.setHorizontalSpacing(14)
        form.setVerticalSpacing(12)
        form.addWidget(QLabel("Путь", self), 0, 0)
        form.addWidget(self.app_path_input, 0, 1)
        form.addWidget(browse_button, 0, 2)
        form.addWidget(QLabel("Название", self), 1, 0)
        form.addWidget(self.app_display_name_input, 1, 1, 1, 2)
        form.addWidget(QLabel("app_id", self), 2, 0)
        form.addWidget(self.app_id_input, 2, 1, 1, 2)
        form.addWidget(QLabel("Сленг", self), 3, 0)
        form.addWidget(self.app_speech_forms_input, 3, 1, 1, 2)
        form.addWidget(self.add_app_button, 4, 2)

        panel = QFrame(self)
        panel.setObjectName("glassPanel")
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(20, 20, 20, 20)
        panel_layout.setSpacing(14)
        panel_layout.addLayout(form)
        panel_layout.addWidget(QLabel("Прогресс", self))
        panel_layout.addWidget(self.app_progress_view, 1)

        tab = QWidget(self)
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(0, 14, 0, 0)
        layout.addWidget(panel, 1)
        return tab

    def _build_apps_tab_v2(self) -> QWidget:
        self.apps_search_input = QLineEdit(self)
        self.apps_search_input.setPlaceholderText("Поиск по датасету и добавленным приложениям")
        self.apps_search_input.textChanged.connect(self._filter_apps_catalog)

        self.new_app_button = QPushButton("Добавить приложение", self)
        self.new_app_button.setProperty("kind", "primary")
        self.new_app_button.clicked.connect(self._open_add_app_dialog)

        self.refresh_apps_catalog_button = QPushButton("Обновить", self)
        self.refresh_apps_catalog_button.clicked.connect(self._refresh_apps_page)

        self.app_training_status_label = QLabel("Готов к изменениям датасета", self)
        self.app_training_status_label.setObjectName("sectionTitle")
        self.app_training_detail_label = QLabel("Добавление, редактирование и удаление будут переобучать open_app и skill_classifier", self)
        self.app_training_detail_label.setObjectName("hintLabel")
        self.app_training_progress = QProgressBar(self)
        self.app_training_progress.setRange(0, 100)
        self.app_training_progress.setValue(0)
        self.app_training_progress.setTextVisible(False)

        self.apps_catalog_table = QTableWidget(self)
        self.apps_catalog_table.setObjectName("historyTable")
        self.apps_catalog_table.setColumnCount(5)
        self.apps_catalog_table.setHorizontalHeaderLabels(["Название", "app_id", "Статус", "Фразы", ""])
        self.apps_catalog_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.apps_catalog_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.apps_catalog_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.apps_catalog_table.verticalHeader().setVisible(False)
        self.apps_catalog_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.apps_catalog_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.apps_catalog_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.apps_catalog_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.apps_catalog_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.apps_catalog_table.setFixedHeight(520)
        self.apps_catalog_table.itemDoubleClicked.connect(lambda item: self._edit_app_from_catalog_row(item.row()))

        self.app_progress_view = QPlainTextEdit(self)
        self.app_progress_view.setObjectName("jsonView")
        self.app_progress_view.setReadOnly(True)
        self.app_progress_view.setFixedHeight(120)
        self.app_progress_view.setPlainText("Готов")

        toolbar = QHBoxLayout()
        toolbar.setSpacing(10)
        toolbar.addWidget(self.apps_search_input, 1)
        toolbar.addWidget(self.new_app_button)
        toolbar.addWidget(self.refresh_apps_catalog_button)

        status_panel = QFrame(self)
        status_panel.setObjectName("glassPanel")
        status_layout = QVBoxLayout(status_panel)
        status_layout.setContentsMargins(14, 12, 14, 12)
        status_layout.setSpacing(8)
        status_layout.addWidget(self.app_training_status_label)
        status_layout.addWidget(self.app_training_detail_label)
        status_layout.addWidget(self.app_training_progress)

        panel = QFrame(self)
        panel.setObjectName("glassPanel")
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(20, 20, 20, 20)
        panel_layout.setSpacing(14)
        panel_layout.addLayout(toolbar)
        panel_layout.addWidget(status_panel)
        panel_layout.addWidget(self.apps_catalog_table)
        panel_layout.addWidget(QLabel("Прогресс", self))
        panel_layout.addWidget(self.app_progress_view)

        tab = QWidget(self)
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(0, 14, 0, 0)
        layout.addWidget(panel, 1)
        self._filter_apps_catalog()
        return tab

    def _build_settings_tab(self) -> QWidget:
        voice = self.settings.voice

        self.hotkey_enabled_checkbox = QCheckBox("Текстовый hotkey", self)
        self.hotkey_enabled_checkbox.setChecked(self.settings.text_hotkey_enabled and not self.hotkey_locked)
        self.hotkey_enabled_checkbox.setEnabled(not self.hotkey_locked)

        self.hotkey_editor = QKeySequenceEdit(self)
        self.hotkey_editor.setKeySequence(QKeySequence(self.settings.text_hotkey_sequence))
        self.hotkey_editor.setEnabled(not self.hotkey_locked)

        self.voice_mode_combo = QComboBox(self)
        for label, value in [("По hotkey", "hotkey"), ("Фоновое прослушивание", "continuous"), ("Выключен", "off")]:
            self.voice_mode_combo.addItem(label, value)
        self.voice_mode_combo.setCurrentIndex(max(0, self.voice_mode_combo.findData(voice.mode)))

        self.voice_hotkey_enabled_checkbox = QCheckBox("Голосовой hotkey", self)
        self.voice_hotkey_enabled_checkbox.setChecked(voice.hotkey_enabled and not self.hotkey_locked)
        self.voice_hotkey_enabled_checkbox.setEnabled(not self.hotkey_locked)

        self.voice_hotkey_editor = QKeySequenceEdit(self)
        self.voice_hotkey_editor.setKeySequence(QKeySequence(voice.hotkey_sequence))
        self.voice_hotkey_editor.setEnabled(not self.hotkey_locked)

        self.agent_names_input = QPlainTextEdit(self)
        self.agent_names_input.setObjectName("summaryView")
        self.agent_names_input.setFixedHeight(74)
        self.agent_names_input.setPlainText("\n".join(voice.agent_names))

        self.require_wake_word_checkbox = QCheckBox("Требовать имя агента в фоне", self)
        self.require_wake_word_checkbox.setChecked(voice.require_wake_word_for_continuous)

        self.preload_model_checkbox = QCheckBox("Прогревать модель при запуске", self)
        self.preload_model_checkbox.setChecked(voice.preload_model_on_startup)

        self.microphone_device_combo = QComboBox(self)
        self.microphone_device_combo.setEditable(True)
        self._populate_microphone_devices(voice.microphone_device)

        self.refresh_microphones_button = QPushButton("Обновить", self)
        self.refresh_microphones_button.clicked.connect(
            lambda: self._populate_microphone_devices(self._combo_data_or_text(self.microphone_device_combo))
        )

        self.stt_profile_combo = QComboBox(self)
        for label, value in [
            ("Turbo local", "turbo"),
            ("Auto balanced", "auto"),
            ("CPU fast", "cpu"),
            ("Accuracy first", "accuracy"),
            ("Custom", "custom"),
        ]:
            self.stt_profile_combo.addItem(label, value)
        self.stt_profile_combo.setCurrentIndex(max(0, self.stt_profile_combo.findData(voice.stt.profile)))

        self.stt_model_combo = QComboBox(self)
        self.stt_model_combo.setEditable(True)
        for model in STT_MODEL_CHOICES:
            self.stt_model_combo.addItem(model, model)
        if self.stt_model_combo.findText(voice.stt.model_size) < 0:
            self.stt_model_combo.addItem(voice.stt.model_size, voice.stt.model_size)
        self.stt_model_combo.setCurrentText(voice.stt.model_size)

        self.stt_device_combo = QComboBox(self)
        for device in STT_DEVICE_CHOICES:
            self.stt_device_combo.addItem(device, device)
        self.stt_device_combo.setCurrentIndex(max(0, self.stt_device_combo.findData(voice.stt.device)))

        self.stt_compute_combo = QComboBox(self)
        for compute in STT_COMPUTE_CHOICES:
            self.stt_compute_combo.addItem(compute, compute)
        self.stt_compute_combo.setCurrentIndex(max(0, self.stt_compute_combo.findData(voice.stt.compute_type)))
        self.stt_model_combo.currentTextChanged.connect(self._switch_stt_profile_to_custom)
        self.stt_device_combo.currentIndexChanged.connect(self._switch_stt_profile_to_custom)
        self.stt_compute_combo.currentIndexChanged.connect(self._switch_stt_profile_to_custom)

        self.stt_timeout_input = QLineEdit(self)
        self.stt_timeout_input.setText(str(voice.stt.transcribe_timeout_s))

        self.vad_sensitivity_input = QLineEdit(self)
        self.vad_sensitivity_input.setText(str(voice.vad.sensitivity))
        self.vad_hotkey_silence_input = QLineEdit(self)
        self.vad_hotkey_silence_input.setText(str(voice.vad.hotkey_silence_ms))
        self.vad_continuous_silence_input = QLineEdit(self)
        self.vad_continuous_silence_input.setText(str(voice.vad.continuous_silence_ms))
        self.vad_max_duration_input = QLineEdit(self)
        self.vad_max_duration_input.setText(str(voice.vad.max_utterance_ms))

        self.hotkey_apply_button = QPushButton("Сохранить настройки", self)
        self.hotkey_apply_button.setProperty("kind", "primary")
        self.hotkey_apply_button.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_DialogApplyButton))
        self.hotkey_apply_button.clicked.connect(self._apply_settings)

        self.voice_test_button = QPushButton("Проверить микрофон", self)
        self.voice_test_button.clicked.connect(self.voice_test_requested.emit)

        self.hotkey_status_label = QLabel("", self)
        self.hotkey_status_label.setObjectName("hintLabel")

        form = QGridLayout()
        form.setHorizontalSpacing(14)
        form.setVerticalSpacing(12)
        form.addWidget(QLabel("Текстовый hotkey", self), 0, 0)
        form.addWidget(self.hotkey_enabled_checkbox, 0, 1)
        form.addWidget(self.hotkey_editor, 0, 2)
        form.addWidget(QLabel("Голосовой режим", self), 1, 0)
        form.addWidget(self.voice_mode_combo, 1, 1)
        form.addWidget(self.voice_hotkey_enabled_checkbox, 1, 2)
        form.addWidget(QLabel("Голосовой hotkey", self), 2, 0)
        form.addWidget(self.voice_hotkey_editor, 2, 1, 1, 2)
        form.addWidget(QLabel("Имена агента", self), 3, 0)
        form.addWidget(self.agent_names_input, 3, 1, 1, 2)
        form.addWidget(QLabel("Микрофон", self), 4, 0)
        form.addWidget(self.microphone_device_combo, 4, 1)
        mic_buttons = QHBoxLayout()
        mic_buttons.setSpacing(8)
        mic_buttons.addWidget(self.refresh_microphones_button)
        mic_buttons.addWidget(self.voice_test_button)
        form.addLayout(mic_buttons, 4, 2)
        form.addWidget(QLabel("STT профиль", self), 5, 0)
        form.addWidget(self.stt_profile_combo, 5, 1)
        form.addWidget(self.preload_model_checkbox, 5, 2)
        form.addWidget(QLabel("Модель / device / compute", self), 6, 0)
        form.addWidget(self.stt_model_combo, 6, 1)
        form.addWidget(self.stt_device_combo, 6, 2)
        form.addWidget(self.stt_compute_combo, 7, 2)
        form.addWidget(QLabel("VAD sensitivity", self), 7, 0)
        form.addWidget(self.vad_sensitivity_input, 7, 1)
        form.addWidget(QLabel("Silence hotkey / фон", self), 8, 0)
        form.addWidget(self.vad_hotkey_silence_input, 8, 1)
        form.addWidget(self.vad_continuous_silence_input, 8, 2)
        form.addWidget(QLabel("Max utterance ms", self), 9, 0)
        form.addWidget(self.vad_max_duration_input, 9, 1)
        form.addWidget(self.require_wake_word_checkbox, 9, 2)
        form.addWidget(QLabel("Max STT seconds", self), 10, 0)
        form.addWidget(self.stt_timeout_input, 10, 1)
        form.addWidget(self.hotkey_apply_button, 11, 2)
        form.addWidget(self.hotkey_status_label, 12, 1, 1, 2)

        panel = QFrame(self)
        panel.setObjectName("glassPanel")
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(20, 20, 20, 20)
        panel_layout.setSpacing(16)
        panel_layout.addLayout(form)
        panel_layout.addStretch(1)

        tab = QWidget(self)
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(0, 14, 0, 0)
        layout.addWidget(panel)
        return tab

    def _wire_runner(self) -> None:
        self.runner.started.connect(self.handle_started)
        self.runner.succeeded.connect(self.handle_success)
        self.runner.failed.connect(self.handle_failure)
        self.runner.finished.connect(self.handle_finished)
        self.user_app_runner.progress.connect(self._handle_user_app_progress)
        self.user_app_runner.succeeded.connect(self._handle_user_app_success)
        self.user_app_runner.failed.connect(self._handle_user_app_failure)
        self.user_app_runner.finished.connect(self._handle_user_app_finished)
        self.user_app_runner.windows_apps_loaded.connect(self._handle_windows_apps_loaded)
        self.user_app_runner.windows_apps_failed.connect(self._handle_windows_apps_failed)
        self.user_app_runner.user_apps_loaded.connect(self._handle_user_apps_loaded)
        self.user_app_runner.user_apps_failed.connect(self._handle_user_apps_failed)

    def _submit(self) -> None:
        text = self.command_input.text().strip()
        if self.runner.run_command(text, execute=self.execute_checkbox.isChecked()):
            self.command_input.selectAll()
            self._pulse_widget(self.run_button)

    @Slot(str)
    def handle_started(self, command: str) -> None:
        self.run_button.setEnabled(False)
        self._set_status(f"Выполняю: {command}", "running")

    @Slot(object)
    def handle_success(self, output: PipelineOutput) -> None:
        self._set_status(output_title(output), "success")
        self.summary_view.setPlainText(output_summary(output))
        self.json_view.setPlainText(output_to_json(output))
        self.refresh_history(select_request_id=output.tool_call.request_id)

    @Slot(str)
    def handle_failure(self, message: str) -> None:
        self._set_status(message, "error")
        self.summary_view.setPlainText(message)
        self.json_view.setPlainText(error_to_json(message))

    @Slot()
    def handle_finished(self) -> None:
        self.run_button.setEnabled(True)

    def show_front(self) -> None:
        self.show()
        self.raise_()
        self.activateWindow()
        self.command_input.setFocus()
        self._fade_window()

    def refresh_history(self, select_request_id: str | None = None) -> None:
        current_id = select_request_id or self._selected_history_id()
        self.history_entries = self.history_store.load_entries()
        self.history_table.setRowCount(len(self.history_entries))

        selected_row = -1
        for row, entry in enumerate(self.history_entries):
            values = [
                entry.timestamp,
                entry.source,
                entry.raw_text,
                entry.skill,
                json.dumps(entry.args, ensure_ascii=False),
                entry.confidence,
                entry.result,
                entry.feedback_label(),
            ]

            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setData(Qt.ItemDataRole.UserRole, entry.request_id)
                if column in {1, 3, 5, 7}:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.history_table.setItem(row, column, item)

            if entry.request_id == current_id:
                selected_row = row

        if selected_row >= 0:
            self.history_table.selectRow(selected_row)
        elif self.history_entries:
            self.history_table.selectRow(0)
        else:
            self.history_detail.setPlainText("История пуста")

    def set_hotkey_status(self, message: str, ok: bool = True) -> None:
        self.hotkey_status_label.setText(message)
        self.hotkey_status_label.setProperty("state", "ok" if ok else "error")
        self._refresh_widget_style(self.hotkey_status_label)

    def set_voice_status(self, title: str, detail: str = "") -> None:
        if hasattr(self, "voice_status_label"):
            self.voice_status_label.setText(title)
        if hasattr(self, "voice_detail_label"):
            self.voice_detail_label.setText(detail)
        if hasattr(self, "voice_level"):
            self.voice_level.setValue(0)

    def set_voice_level(self, level: float) -> None:
        if hasattr(self, "voice_level"):
            self.voice_level.setValue(max(0, min(100, int(level * 900))))

    def _selected_history_id(self) -> str | None:
        selected = self.history_table.selectedItems()
        if not selected:
            return None
        request_id = selected[0].data(Qt.ItemDataRole.UserRole)
        return str(request_id) if request_id else None

    def _selected_history_entry(self) -> HistoryEntry | None:
        request_id = self._selected_history_id()
        if not request_id:
            return None
        for entry in self.history_entries:
            if entry.request_id == request_id:
                return entry
        return None

    def _show_selected_history(self) -> None:
        entry = self._selected_history_entry()
        if entry is None:
            return

        self.history_detail.setPlainText(
            json.dumps(entry.to_display_dict(), ensure_ascii=False, indent=2)
        )

    def _mark_selected_history(self, status: str) -> None:
        entry = self._selected_history_entry()
        if entry is None:
            self._set_status("Выбери запись в истории", "error")
            return

        self.history_store.mark(entry, status)
        self._set_status("Отметка сохранена", "success")
        self._pulse_widget(self.mark_correct_button if status == "correct" else self.mark_incorrect_button)
        self.refresh_history(select_request_id=entry.request_id)

    def _populate_microphone_devices(self, selected: str = "") -> None:
        if not hasattr(self, "microphone_device_combo"):
            return

        current = selected.strip()
        self.microphone_device_combo.blockSignals(True)
        self.microphone_device_combo.clear()
        self.microphone_device_combo.addItem("Системный микрофон по умолчанию", "")

        for device in list_input_devices():
            device_id = str(device.get("id", ""))
            name = str(device.get("name", f"Input {device_id}"))
            channels = device.get("channels", "")
            label = f"{name}  ·  id {device_id}"
            if channels:
                label = f"{label}  ·  {channels} ch"
            self.microphone_device_combo.addItem(label, device_id)

        if current:
            index = self.microphone_device_combo.findData(current)
            if index < 0:
                self.microphone_device_combo.addItem(current, current)
                index = self.microphone_device_combo.findData(current)
            self.microphone_device_combo.setCurrentIndex(max(0, index))
        else:
            self.microphone_device_combo.setCurrentIndex(0)
        self.microphone_device_combo.blockSignals(False)

    def _combo_data_or_text(self, combo: QComboBox) -> str:
        data = combo.currentData()
        if data is not None:
            return str(data)
        return combo.currentText().strip()

    def _switch_stt_profile_to_custom(self, *_args) -> None:
        if not hasattr(self, "stt_profile_combo"):
            return
        index = self.stt_profile_combo.findData("custom")
        if index >= 0:
            self.stt_profile_combo.setCurrentIndex(index)

    def _apply_settings(self) -> None:
        sequence = self.hotkey_editor.keySequence().toString(QKeySequence.SequenceFormat.PortableText)
        voice_sequence = self.voice_hotkey_editor.keySequence().toString(QKeySequence.SequenceFormat.PortableText)
        voice = VoiceSettings(
            mode=str(self.voice_mode_combo.currentData() or "hotkey"),
            hotkey_enabled=self.voice_hotkey_enabled_checkbox.isChecked(),
            hotkey_sequence=voice_sequence,
            microphone_device=self._combo_data_or_text(self.microphone_device_combo),
            agent_names=tuple(self._lines_from_plain_text(self.agent_names_input)),
            require_wake_word_for_continuous=self.require_wake_word_checkbox.isChecked(),
            preload_model_on_startup=self.preload_model_checkbox.isChecked(),
            stt=SttSettings(
                profile=str(self.stt_profile_combo.currentData() or "auto"),
                model_size=self.stt_model_combo.currentText().strip() or "turbo",
                device=str(self.stt_device_combo.currentData() or self.stt_device_combo.currentText() or "auto"),
                compute_type=str(self.stt_compute_combo.currentData() or self.stt_compute_combo.currentText() or "auto"),
                transcribe_timeout_s=self._float_from_input(self.stt_timeout_input.text(), 30.0),
            ),
            vad=VadSettings(
                sensitivity=self._float_from_input(self.vad_sensitivity_input.text(), 0.012),
                hotkey_silence_ms=self._int_from_input(self.vad_hotkey_silence_input.text(), 500),
                continuous_silence_ms=self._int_from_input(self.vad_continuous_silence_input.text(), 700),
                max_utterance_ms=self._int_from_input(self.vad_max_duration_input.text(), 7000),
            ),
        ).normalized()
        self.settings = UiSettings(
            text_hotkey_enabled=self.hotkey_enabled_checkbox.isChecked(),
            text_hotkey_sequence=sequence,
            voice=voice,
        )
        self.hotkey_settings_changed.emit(self.hotkey_enabled_checkbox.isChecked(), sequence)
        self.settings_changed.emit(self.settings)

    def _lines_from_plain_text(self, widget: QPlainTextEdit) -> list[str]:
        values = []
        seen = set()
        for line in widget.toPlainText().replace(",", "\n").splitlines():
            value = " ".join(line.strip().lower().split())
            if value and value not in seen:
                seen.add(value)
                values.append(value)
        return values

    def _int_from_input(self, value: str, default: int) -> int:
        try:
            return int(value)
        except ValueError:
            return default

    def _float_from_input(self, value: str, default: float) -> float:
        try:
            return float(value)
        except ValueError:
            return default

    def _refresh_apps_page(self) -> None:
        self._load_windows_apps()
        self._load_user_apps()
        self._filter_apps_catalog()

    def _build_apps_catalog_rows(self) -> list[dict[str, object]]:
        rows: list[dict[str, object]] = []
        overrides = load_app_catalog_overrides()
        for app_id, payload in BUILTIN_APP_CATALOG.items():
            override = overrides.get(app_id)
            if override is not None and override.disabled:
                continue

            surface_forms = payload.get("surface_forms", []) if isinstance(payload, dict) else []
            if not isinstance(surface_forms, list):
                surface_forms = []
            custom_forms = override.speech_forms if override is not None else []
            display_name = str(surface_forms[0]) if surface_forms else str(app_id)
            rows.append({
                "display_name": display_name,
                "app_id": str(app_id),
                "status": "Встроенное · изменено" if custom_forms else "Встроенное",
                "source": "builtin",
                "speech_forms": [str(item) for item in [*surface_forms[:8], *custom_forms]],
                "custom_speech_forms": [str(item) for item in custom_forms],
                "editable": True,
            })

        for app in self._user_apps:
            speech_forms = app.get("speech_forms", [])
            if not isinstance(speech_forms, list):
                speech_forms = []
            rows.append({
                "display_name": str(app.get("display_name", "")),
                "app_id": str(app.get("app_id", "")),
                "status": "Добавлено",
                "source": "user",
                "launch_type": str(app.get("launch_type", "")),
                "speech_forms": [str(item) for item in speech_forms],
                "custom_speech_forms": [str(item) for item in speech_forms],
                "record": app,
                "editable": True,
            })

        return sorted(rows, key=lambda item: (str(item["source"]) != "user", str(item["display_name"]).lower()))

    def _filter_apps_catalog(self) -> None:
        if not hasattr(self, "apps_catalog_table"):
            return

        query = " ".join(self.apps_search_input.text().lower().split()) if hasattr(self, "apps_search_input") else ""
        rows = []
        for row in self._build_apps_catalog_rows():
            speech_forms = row.get("speech_forms", [])
            haystack = " ".join([
                str(row.get("display_name", "")),
                str(row.get("app_id", "")),
                str(row.get("status", "")),
                " ".join(str(item) for item in speech_forms if item),
            ]).lower()
            if not query or query in haystack:
                rows.append(row)

        self.apps_catalog_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            speech_forms = row.get("speech_forms", [])
            values = [
                str(row.get("display_name", "")),
                str(row.get("app_id", "")),
                str(row.get("status", "")),
                ", ".join(str(item) for item in speech_forms if item),
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setData(Qt.ItemDataRole.UserRole, row)
                self.apps_catalog_table.setItem(row_index, column, item)

            edit_button = QPushButton("✎", self)
            edit_button.setToolTip("Редактировать сленг")
            edit_button.setProperty("kind", "ghost")
            edit_button.setEnabled(bool(row.get("editable")))
            edit_button.clicked.connect(lambda _checked=False, item=row: self._open_edit_app_dialog(item.get("record") or item))
            self.apps_catalog_table.setCellWidget(row_index, 4, edit_button)

    def _edit_app_from_catalog_row(self, row: int) -> None:
        item = self.apps_catalog_table.item(row, 0) if hasattr(self, "apps_catalog_table") else None
        if item is None:
            return
        payload = item.data(Qt.ItemDataRole.UserRole)
        if not isinstance(payload, dict) or not payload.get("editable"):
            return
        self._open_edit_app_dialog(payload.get("record") or payload)

    def _open_add_app_dialog(self) -> None:
        if self._active_app_dialog is not None:
            self._active_app_dialog.raise_()
            self._active_app_dialog.activateWindow()
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Добавить приложение")
        dialog.setMinimumSize(780, 640)
        dialog.setModal(False)
        self._active_app_dialog = dialog
        self._build_app_dialog(dialog, mode="new")
        dialog.finished.connect(self._clear_app_dialog_refs)
        dialog.show()
        dialog.raise_()
        dialog.activateWindow()

    def _open_edit_app_dialog(self, app: object) -> None:
        if not isinstance(app, dict):
            return
        if self._active_app_dialog is not None:
            self._active_app_dialog.close()

        dialog = QDialog(self)
        dialog.setWindowTitle("Редактировать приложение")
        dialog.setMinimumSize(680, 460)
        dialog.setModal(False)
        self._active_app_dialog = dialog
        self._build_app_dialog(dialog, mode="edit", app=app)
        dialog.finished.connect(self._clear_app_dialog_refs)
        dialog.show()
        dialog.raise_()
        dialog.activateWindow()

    def _clear_app_dialog_refs(self) -> None:
        self._active_app_dialog = None
        self._selected_windows_app = None
        self._selected_user_app = None
        self._app_form_mode = "new"
        for name in (
            "app_windows_mode_radio",
            "app_path_mode_radio",
            "windows_app_search_input",
            "refresh_windows_apps_button",
            "windows_apps_table",
            "app_path_input",
            "app_display_name_input",
            "app_id_input",
            "app_speech_forms_input",
            "add_app_button",
            "update_app_button",
            "delete_app_button",
            "app_form_mode_label",
            "app_id_status_label",
            "dialog_app_progress_view",
            "windows_apps_panel",
            "path_panel",
        ):
            if hasattr(self, name):
                delattr(self, name)

    def _build_app_dialog(self, dialog: QDialog, mode: str, app: dict[str, object] | None = None) -> None:
        self.app_windows_mode_radio = QRadioButton("Из списка Windows", dialog)
        self.app_windows_mode_radio.setChecked(mode == "new")
        self.app_windows_mode_radio.toggled.connect(self._sync_app_mode)

        self.app_path_mode_radio = QRadioButton("По пути .exe", dialog)
        self.app_path_mode_radio.toggled.connect(self._sync_app_mode)

        self.windows_app_search_input = QLineEdit(dialog)
        self.windows_app_search_input.setPlaceholderText("Поиск в приложениях Windows")
        self.windows_app_search_input.textChanged.connect(self._filter_windows_apps)

        self.refresh_windows_apps_button = QPushButton("Обновить список", dialog)
        self.refresh_windows_apps_button.clicked.connect(self._load_windows_apps)

        self.windows_apps_table = QTableWidget(dialog)
        self.windows_apps_table.setObjectName("historyTable")
        self.windows_apps_table.setColumnCount(3)
        self.windows_apps_table.setHorizontalHeaderLabels(["Название", "ID", "Источник"])
        self.windows_apps_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.windows_apps_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.windows_apps_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.windows_apps_table.verticalHeader().setVisible(False)
        self.windows_apps_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.windows_apps_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.windows_apps_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.windows_apps_table.setFixedHeight(220)
        self.windows_apps_table.itemSelectionChanged.connect(self._select_windows_app)

        self.app_path_input = QLineEdit(dialog)
        self.app_path_input.setPlaceholderText(r"D:\Tools\App\app.exe")
        self.app_path_input.textChanged.connect(self._update_suggested_app_id)

        browse_button = QPushButton("Выбрать", dialog)
        browse_button.clicked.connect(self._browse_app_path)

        self.app_display_name_input = QLineEdit(dialog)
        self.app_display_name_input.setPlaceholderText("Название приложения")
        self.app_display_name_input.textChanged.connect(self._update_suggested_app_id)

        self.app_id_input = QLineEdit(dialog)
        self.app_id_input.setPlaceholderText("app_id")
        self.app_id_input.textEdited.connect(self._mark_app_id_changed)
        self.app_id_input.textChanged.connect(self._validate_app_form)

        self.app_speech_forms_input = QPlainTextEdit(dialog)
        self.app_speech_forms_input.setObjectName("summaryView")
        self.app_speech_forms_input.setPlaceholderText("Сленговые названия, по одному на строку")
        self.app_speech_forms_input.setFixedHeight(110)

        self.add_app_button = QPushButton("Добавить и обучить", dialog)
        self.add_app_button.setProperty("kind", "primary")
        self.add_app_button.clicked.connect(self._submit_user_app)

        self.update_app_button = QPushButton("Сохранить и дообучить", dialog)
        self.update_app_button.clicked.connect(self._submit_update_user_app)

        self.delete_app_button = QPushButton("Удалить", dialog)
        self.delete_app_button.setProperty("kind", "warning")
        self.delete_app_button.clicked.connect(self._submit_delete_user_app)

        close_button = QPushButton("Закрыть", dialog)
        close_button.clicked.connect(dialog.close)

        self.app_form_mode_label = QLabel("Новое приложение" if mode == "new" else "Редактирование", dialog)
        self.app_form_mode_label.setObjectName("sectionTitle")

        self.app_id_status_label = QLabel("", dialog)
        self.app_id_status_label.setObjectName("hintLabel")

        self.dialog_app_progress_view = QPlainTextEdit(dialog)
        self.dialog_app_progress_view.setObjectName("jsonView")
        self.dialog_app_progress_view.setReadOnly(True)
        self.dialog_app_progress_view.setFixedHeight(130)
        self.dialog_app_progress_view.setPlainText("Готов")

        self.windows_apps_panel = QFrame(dialog)
        self.windows_apps_panel.setObjectName("glassPanel")
        windows_layout = QVBoxLayout(self.windows_apps_panel)
        windows_layout.setContentsMargins(14, 14, 14, 14)
        windows_toolbar = QHBoxLayout()
        windows_toolbar.addWidget(self.windows_app_search_input, 1)
        windows_toolbar.addWidget(self.refresh_windows_apps_button)
        windows_layout.addLayout(windows_toolbar)
        windows_layout.addWidget(self.windows_apps_table)

        self.path_panel = QFrame(dialog)
        self.path_panel.setObjectName("glassPanel")
        path_layout = QGridLayout(self.path_panel)
        path_layout.setContentsMargins(14, 14, 14, 14)
        path_layout.addWidget(QLabel("Путь", dialog), 0, 0)
        path_layout.addWidget(self.app_path_input, 0, 1)
        path_layout.addWidget(browse_button, 0, 2)

        form = QGridLayout()
        form.setHorizontalSpacing(12)
        form.setVerticalSpacing(10)
        form.addWidget(QLabel("Название", dialog), 0, 0)
        form.addWidget(self.app_display_name_input, 0, 1, 1, 3)
        form.addWidget(QLabel("app_id", dialog), 1, 0)
        form.addWidget(self.app_id_input, 1, 1, 1, 3)
        form.addWidget(self.app_id_status_label, 2, 1, 1, 3)
        form.addWidget(QLabel("Сленг", dialog), 3, 0)
        form.addWidget(self.app_speech_forms_input, 3, 1, 1, 3)

        action_row = QHBoxLayout()
        action_row.addStretch(1)
        action_row.addWidget(self.delete_app_button)
        action_row.addWidget(self.update_app_button)
        action_row.addWidget(self.add_app_button)
        action_row.addWidget(close_button)

        mode_row = QHBoxLayout()
        mode_row.addWidget(self.app_form_mode_label)
        mode_row.addStretch(1)
        mode_row.addWidget(self.app_windows_mode_radio)
        mode_row.addWidget(self.app_path_mode_radio)

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)
        layout.addLayout(mode_row)
        layout.addWidget(self.windows_apps_panel)
        layout.addWidget(self.path_panel)
        layout.addLayout(form)
        layout.addWidget(QLabel("Прогресс", dialog))
        layout.addWidget(self.dialog_app_progress_view)
        layout.addLayout(action_row)

        if mode == "edit" and app is not None:
            self._set_app_form_edit(app)
        else:
            self._set_app_form_new()
        self._filter_windows_apps()

    def _sync_app_mode(self) -> None:
        if not hasattr(self, "app_windows_mode_radio"):
            return
        windows_mode = self.app_windows_mode_radio.isChecked()
        self.windows_apps_panel.setVisible(windows_mode)
        self.path_panel.setVisible(not windows_mode)
        if windows_mode:
            self.app_path_input.clear()
            if self._selected_windows_app:
                self._apply_selected_windows_app(self._selected_windows_app)
        else:
            self._selected_windows_app = None
            self._update_suggested_app_id()
        if self._selected_user_app is None:
            self.app_display_name_input.setReadOnly(False)
            self.app_id_input.setReadOnly(False)
        self._validate_app_form()

    def _set_app_form_new(self) -> None:
        if not hasattr(self, "app_display_name_input"):
            self._open_add_app_dialog()
            return

        self._app_form_mode = "new"
        self._selected_user_app = None
        self._selected_windows_app = None
        self._app_id_user_changed = False
        if hasattr(self, "windows_apps_table"):
            self.windows_apps_table.clearSelection()
        self.app_display_name_input.clear()
        self.app_id_input.clear()
        self.app_path_input.clear()
        self.app_speech_forms_input.clear()
        if hasattr(self, "app_windows_mode_radio"):
            self.app_windows_mode_radio.setVisible(True)
            self.app_path_mode_radio.setVisible(True)
        self.app_display_name_input.setReadOnly(False)
        self.app_id_input.setReadOnly(False)
        self.add_app_button.setEnabled(True)
        self.add_app_button.setVisible(True)
        self.update_app_button.setEnabled(False)
        self.update_app_button.setVisible(False)
        self.delete_app_button.setEnabled(False)
        self.delete_app_button.setVisible(False)
        self.app_form_mode_label.setText("Новое приложение")
        self._sync_app_mode()
        self._validate_app_form()

    def _set_app_form_edit(self, app: dict[str, object]) -> None:
        self._app_form_mode = "edit"
        self._selected_user_app = app
        self._selected_windows_app = None
        self.app_form_mode_label.setText("Редактирование")
        self.add_app_button.setEnabled(False)
        self.add_app_button.setVisible(False)
        self.update_app_button.setEnabled(True)
        self.update_app_button.setVisible(True)
        self.delete_app_button.setEnabled(True)
        self.delete_app_button.setVisible(True)
        if hasattr(self, "app_windows_mode_radio"):
            self.app_windows_mode_radio.setVisible(False)
            self.app_path_mode_radio.setVisible(False)
        if hasattr(self, "windows_apps_panel"):
            self.windows_apps_panel.setVisible(False)
        if hasattr(self, "path_panel"):
            self.path_panel.setVisible(False)
        self.app_display_name_input.setText(str(app.get("display_name", "")))
        self.app_id_input.setText(str(app.get("app_id", "")))
        self.app_display_name_input.setReadOnly(True)
        self.app_id_input.setReadOnly(True)
        speech_forms = app.get("custom_speech_forms", app.get("speech_forms", []))
        if not isinstance(speech_forms, list):
            speech_forms = []
        self.app_speech_forms_input.setPlainText("\n".join(str(item) for item in speech_forms))
        self._validate_app_form()

    def _validate_app_form(self) -> None:
        if not hasattr(self, "app_id_status_label"):
            return

        app_id = self.app_id_input.text().strip()
        if self._app_form_mode == "edit":
            self.app_id_status_label.setText("Название и app_id защищены; редактируется только сленг")
            self.app_id_status_label.setProperty("state", "ok")
            self._refresh_widget_style(self.app_id_status_label)
            return

        occupied_user_ids = {
            str(app.get("app_id", "")).strip()
            for app in self._user_apps
            if str(app.get("app_id", "")).strip()
        }
        occupied_model_ids = set(BUILTIN_APP_CATALOG)
        if not app_id:
            self.app_id_status_label.setText("")
            self.add_app_button.setEnabled(False)
        elif app_id in occupied_user_ids or app_id in occupied_model_ids:
            self.app_id_status_label.setText(f"app_id уже занят в датасете: {app_id}")
            self.app_id_status_label.setProperty("state", "error")
            self.add_app_button.setEnabled(False)
        else:
            self.app_id_status_label.setText("app_id свободен для пользовательского приложения")
            self.app_id_status_label.setProperty("state", "ok")
            self.add_app_button.setEnabled(True)
        self._refresh_widget_style(self.app_id_status_label)

    def _load_windows_apps(self) -> None:
        if hasattr(self, "refresh_windows_apps_button"):
            self.refresh_windows_apps_button.setEnabled(False)
        self.app_progress_view.setPlainText("Загружаю список Windows-приложений")
        if hasattr(self, "dialog_app_progress_view"):
            self.dialog_app_progress_view.setPlainText("Загружаю список Windows-приложений")
        self.user_app_runner.load_windows_apps()

    @Slot(object)
    def _handle_windows_apps_loaded(self, apps) -> None:
        self._windows_apps = list(apps or [])
        if hasattr(self, "refresh_windows_apps_button"):
            self.refresh_windows_apps_button.setEnabled(True)
        if hasattr(self, "windows_apps_table"):
            self._filter_windows_apps()
        self.app_progress_view.setPlainText(f"Найдено приложений: {len(self._windows_apps)}")
        if hasattr(self, "dialog_app_progress_view"):
            self.dialog_app_progress_view.setPlainText(f"Найдено приложений: {len(self._windows_apps)}")

    @Slot(str)
    def _handle_windows_apps_failed(self, message: str) -> None:
        if hasattr(self, "refresh_windows_apps_button"):
            self.refresh_windows_apps_button.setEnabled(True)
        self.app_progress_view.setPlainText(message)
        if hasattr(self, "dialog_app_progress_view"):
            self.dialog_app_progress_view.setPlainText(message)
        self._set_status(message, "error")

    def _load_user_apps(self) -> None:
        self.user_app_runner.load_user_apps()

    @Slot(object)
    def _handle_user_apps_loaded(self, apps) -> None:
        self._user_apps = list(apps or [])
        self._refresh_user_apps_table()
        self._filter_apps_catalog()
        self._validate_app_form()

    @Slot(str)
    def _handle_user_apps_failed(self, message: str) -> None:
        self.app_progress_view.setPlainText(message)
        self._set_status(message, "error")

    def _refresh_user_apps_table(self) -> None:
        if not hasattr(self, "user_apps_table"):
            return

        self.user_apps_table.setRowCount(len(self._user_apps))
        for row, app in enumerate(self._user_apps):
            speech_forms = app.get("speech_forms", [])
            if not isinstance(speech_forms, list):
                speech_forms = []
            values = [
                str(app.get("display_name", "")),
                str(app.get("app_id", "")),
                str(app.get("launch_type", "")),
                ", ".join(str(item) for item in speech_forms),
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setData(Qt.ItemDataRole.UserRole, app)
                self.user_apps_table.setItem(row, column, item)

    def _select_user_app(self) -> None:
        selected = self.user_apps_table.selectedItems()
        if not selected:
            if self._app_form_mode == "edit":
                self._set_app_form_new()
            return

        app = selected[0].data(Qt.ItemDataRole.UserRole)
        if not isinstance(app, dict):
            return

        self._set_app_form_edit(app)

    def _filter_windows_apps(self) -> None:
        if not hasattr(self, "windows_apps_table"):
            return

        query = " ".join(self.windows_app_search_input.text().lower().split())
        rows = []
        for app in self._windows_apps:
            haystack = " ".join([
                app.get("display_name", ""),
                app.get("windows_app_id", ""),
                app.get("source", ""),
            ]).lower()
            if not query or query in haystack:
                rows.append(app)

        self.windows_apps_table.setRowCount(len(rows))
        for row, app in enumerate(rows):
            values = [
                app.get("display_name", ""),
                app.get("windows_app_id", ""),
                app.get("source", ""),
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setData(Qt.ItemDataRole.UserRole, app)
                self.windows_apps_table.setItem(row, column, item)

    def _select_windows_app(self) -> None:
        selected = self.windows_apps_table.selectedItems()
        if not selected:
            return
        app = selected[0].data(Qt.ItemDataRole.UserRole)
        if not isinstance(app, dict):
            return
        self._selected_windows_app = app
        self._selected_user_app = None
        self._app_form_mode = "new"
        self.app_form_mode_label.setText("Новое приложение")
        self.update_app_button.setEnabled(False)
        self.delete_app_button.setEnabled(False)
        self.add_app_button.setEnabled(True)
        self.app_display_name_input.setReadOnly(False)
        self.app_id_input.setReadOnly(False)
        self._apply_selected_windows_app(app)

    def _apply_selected_windows_app(self, app: dict[str, str]) -> None:
        display_name = app.get("display_name", "")
        windows_app_id = app.get("windows_app_id", "")
        self._app_id_user_changed = False
        self.app_display_name_input.setText(display_name)
        if not self._app_id_user_changed:
            self.app_id_input.setText(suggest_app_id(display_name, windows_app_id))
        self._validate_app_form()

    def _browse_app_path(self) -> None:
        path, _filter = QFileDialog.getOpenFileName(
            self,
            "Выбрать приложение",
            "",
            "Applications (*.exe);;All files (*.*)",
        )
        if path:
            self._selected_user_app = None
            self._app_form_mode = "new"
            self.app_form_mode_label.setText("Новое приложение")
            self.update_app_button.setEnabled(False)
            self.delete_app_button.setEnabled(False)
            self.app_display_name_input.setReadOnly(False)
            self.app_id_input.setReadOnly(False)
            self.app_path_input.setText(path)

    def _mark_app_id_changed(self) -> None:
        self._app_id_user_changed = bool(self.app_id_input.text().strip())

    def _update_suggested_app_id(self) -> None:
        if self._app_id_user_changed:
            return

        display_name = self.app_display_name_input.text().strip()
        path = self.app_path_input.text().strip()
        if not display_name and not path:
            self.app_id_input.clear()
            self._validate_app_form()
            return

        self.app_id_input.setText(suggest_app_id(display_name, path or None))
        self._validate_app_form()

    def _submit_user_app(self) -> None:
        speech_forms = self._speech_forms_from_input()
        kwargs = {
            "display_name": self.app_display_name_input.text(),
            "app_id": self.app_id_input.text(),
            "speech_forms": speech_forms,
        }
        if self.app_windows_mode_radio.isChecked():
            selected = self._selected_windows_app or {}
            kwargs.update({
                "windows_app_id": selected.get("windows_app_id", ""),
                "launch_type": selected.get("launch_type", "apps_folder"),
                "launch_target": selected.get("launch_target", ""),
                "path": "",
            })
        else:
            kwargs.update({
                "path": self.app_path_input.text(),
                "windows_app_id": "",
                "launch_type": "exe",
                "launch_target": "",
            })

        if self.user_app_runner.add_app(**kwargs):
            self._last_user_app_action = "add"
            self.add_app_button.setEnabled(False)
            self._set_app_progress_text("Стартую добавление приложения")
            self._set_app_training_status("Проверяю приложение")
            self._set_status("Добавляю приложение", "running")

    def _submit_update_user_app(self) -> None:
        if not self._selected_user_app:
            self._set_status("Выбери добавленное приложение", "error")
            return

        app_id = str(self._selected_user_app.get("app_id", ""))
        if self.user_app_runner.update_app_speech_forms(app_id, self._speech_forms_from_input()):
            self._last_user_app_action = "update"
            self.add_app_button.setEnabled(False)
            self.update_app_button.setEnabled(False)
            self.delete_app_button.setEnabled(False)
            self._set_app_progress_text("Стартую обновление сленга")
            self._set_app_training_status("Сохраняю сленг")
            self._set_status("Обновляю сленг", "running")

    def _submit_delete_user_app(self) -> None:
        if not self._selected_user_app:
            self._set_status("Выбери добавленное приложение", "error")
            return

        app_id = str(self._selected_user_app.get("app_id", ""))
        if self.user_app_runner.delete_app(app_id):
            self._last_user_app_action = "delete"
            self.add_app_button.setEnabled(False)
            self.update_app_button.setEnabled(False)
            self.delete_app_button.setEnabled(False)
            self._set_app_progress_text("Стартую удаление приложения")
            self._set_app_training_status("Удаляю приложение")
            self._set_status("Удаляю приложение", "running")

    def _speech_forms_from_input(self) -> list[str]:
        raw = self.app_speech_forms_input.toPlainText().replace(",", "\n")
        forms = []
        seen = set()
        for line in raw.splitlines():
            value = " ".join(line.strip().lower().split())
            if value and value not in seen:
                seen.add(value)
                forms.append(value)
        return forms

    @Slot(str)
    def _handle_user_app_progress(self, message: str) -> None:
        current = self._current_app_progress_text()
        self._set_app_progress_text(f"{current}\n{message}".strip())
        self._set_app_training_status(message)
        self.app_progress_view.verticalScrollBar().setValue(self.app_progress_view.verticalScrollBar().maximum())
        if hasattr(self, "dialog_app_progress_view"):
            self.dialog_app_progress_view.verticalScrollBar().setValue(self.dialog_app_progress_view.verticalScrollBar().maximum())

    @Slot(object)
    def _handle_user_app_success(self, result) -> None:
        self.runner.reload_pipeline()
        self._load_user_apps()
        payload = result.to_dict() if hasattr(result, "to_dict") else result
        self._set_app_progress_text(json.dumps(payload, ensure_ascii=False, indent=2))
        self._set_app_training_status("Готово")
        if self._last_user_app_action == "delete" and self._active_app_dialog is not None:
            self._active_app_dialog.close()
        elif self._app_form_mode == "new" and hasattr(self, "app_display_name_input"):
            self._set_app_form_new()
        self._set_status("Приложение сохранено и модели обновлены", "success")
        if hasattr(self, "add_app_button"):
            self._pulse_widget(self.add_app_button)

    @Slot(str)
    def _handle_user_app_failure(self, message: str) -> None:
        display_message = self._friendly_user_app_error(message)
        self._set_app_progress_text(display_message)
        self._set_app_training_status("Ошибка", display_message, failed=True)
        self._set_status(display_message, "error")

    @Slot()
    def _handle_user_app_finished(self) -> None:
        if hasattr(self, "add_app_button"):
            self.add_app_button.setEnabled(self._app_form_mode == "new")
        if hasattr(self, "update_app_button"):
            self.update_app_button.setEnabled(self._selected_user_app is not None)
        if hasattr(self, "delete_app_button"):
            self.delete_app_button.setEnabled(self._selected_user_app is not None)
        self._validate_app_form()

    def _current_app_progress_text(self) -> str:
        if hasattr(self, "dialog_app_progress_view"):
            return self.dialog_app_progress_view.toPlainText().strip()
        return self.app_progress_view.toPlainText().strip()

    def _set_app_progress_text(self, text: str) -> None:
        self.app_progress_view.setPlainText(text)
        if hasattr(self, "dialog_app_progress_view"):
            self.dialog_app_progress_view.setPlainText(text)

    def _set_app_training_status(self, message: str, detail: str = "", failed: bool = False) -> None:
        if not hasattr(self, "app_training_status_label"):
            return

        steps = [
            "Проверяю приложение",
            "Сохраняю приложение",
            "Сохраняю сленг",
            "Удаляю приложение",
            "Обновляю индекс",
            "Генерирую датасет open_app",
            "Обучаю open_app",
            "Тестирую open_app",
            "Генерирую датасет skill_classifier",
            "Обучаю skill_classifier",
            "Тестирую skill_classifier",
            "Проверяю новые фразы",
            "Готово",
        ]
        index = next((i for i, step in enumerate(steps) if step == message), -1)
        if failed:
            percent = 100
            title = "Ошибка обучения"
            state = "error"
        elif index >= 0:
            percent = int(((index + 1) / len(steps)) * 100)
            title = message
            state = "ok" if message == "Готово" else "running"
        else:
            percent = max(10, self.app_training_progress.value())
            title = message
            state = "running"

        self.app_training_status_label.setText(title)
        self.app_training_status_label.setProperty("state", state)
        self.app_training_detail_label.setText(detail or " → ".join(steps[max(0, index):index + 3]) if index >= 0 else detail)
        self.app_training_progress.setValue(percent)
        self._refresh_widget_style(self.app_training_status_label)

    def _friendly_user_app_error(self, message: str) -> str:
        if "app_id is already used:" in message or "app_id already exists:" in message:
            app_id = message.rsplit(":", 1)[-1].strip()
            return f"app_id уже занят: {app_id}"
        return message

    def _set_status(self, text: str, state: str) -> None:
        self.status_label.setText(text)
        self.status_label.setProperty("state", state)
        self._refresh_widget_style(self.status_label)
        self._pulse_status()

    def _refresh_widget_style(self, widget: QWidget) -> None:
        widget.style().unpolish(widget)
        widget.style().polish(widget)

    def _fade_window(self) -> None:
        animation = QPropertyAnimation(self, b"windowOpacity", self)
        animation.setDuration(180)
        animation.setStartValue(0.86)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._start_animation(animation)

    def _pulse_status(self) -> None:
        animation = QPropertyAnimation(self.status_effect, b"opacity", self)
        animation.setDuration(260)
        animation.setStartValue(0.55)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._start_animation(animation)

    def _pulse_widget(self, widget: QWidget) -> None:
        effect = QGraphicsOpacityEffect(widget)
        effect.setOpacity(1.0)
        widget.setGraphicsEffect(effect)

        animation = QPropertyAnimation(effect, b"opacity", self)
        animation.setDuration(170)
        animation.setKeyValueAt(0.0, 1.0)
        animation.setKeyValueAt(0.45, 0.58)
        animation.setKeyValueAt(1.0, 1.0)
        animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        animation.finished.connect(lambda: widget.setGraphicsEffect(None))
        self._start_animation(animation)

    def _start_animation(self, animation: QPropertyAnimation) -> None:
        self._animations.append(animation)
        animation.finished.connect(lambda: self._animations.remove(animation) if animation in self._animations else None)
        animation.start()

    def _apply_style(self) -> None:
        self.setStyleSheet(
            """
            QMainWindow, QWidget#appRoot {
                background: #050608;
                color: #f5f7fb;
                font-family: "Segoe UI Variable", "Segoe UI", Arial, sans-serif;
            }
            QFrame#headerPanel, QFrame#glassPanel {
                background: rgba(18, 20, 26, 216);
                border: 1px solid rgba(255, 255, 255, 34);
                border-radius: 8px;
            }
            QLabel#logo {
                background: rgba(255, 255, 255, 18);
                border: 1px solid rgba(255, 255, 255, 46);
                border-radius: 8px;
                padding: 2px;
            }
            QLabel#titleLabel {
                color: #ffffff;
                font-size: 23px;
                font-weight: 650;
                letter-spacing: 0;
            }
            QLabel#subtitleLabel {
                color: rgba(245, 247, 251, 150);
                font-size: 12px;
            }
            QLabel#statusLabel {
                color: #f7f9ff;
                font-size: 13px;
                font-weight: 560;
                padding: 8px 12px;
                background: rgba(255, 255, 255, 16);
                border: 1px solid rgba(255, 255, 255, 42);
                border-radius: 8px;
            }
            QLabel#statusLabel[state="running"] {
                background: rgba(255, 255, 255, 28);
                border-color: rgba(255, 255, 255, 90);
            }
            QLabel#statusLabel[state="success"] {
                background: rgba(82, 210, 156, 28);
                border-color: rgba(141, 255, 210, 95);
            }
            QLabel#statusLabel[state="error"] {
                background: rgba(255, 96, 96, 30);
                border-color: rgba(255, 132, 132, 105);
            }
            QLabel#hintLabel {
                color: rgba(245, 247, 251, 150);
                font-size: 12px;
            }
            QLabel#hintLabel[state="error"] {
                color: #ff9c9c;
            }
            QLabel#hintLabel[state="ok"] {
                color: #a7ffd8;
            }
            QLabel#sectionTitle {
                color: #ffffff;
                font-size: 16px;
                font-weight: 650;
            }
            QLabel#sectionTitle[state="running"] {
                color: #ffffff;
            }
            QLabel#sectionTitle[state="ok"] {
                color: #a7ffd8;
            }
            QLabel#sectionTitle[state="error"] {
                color: #ff9c9c;
            }
            QProgressBar {
                background: rgba(255, 255, 255, 14);
                border: 1px solid rgba(255, 255, 255, 30);
                border-radius: 4px;
                min-height: 8px;
                max-height: 8px;
            }
            QProgressBar::chunk {
                background: rgba(255, 255, 255, 210);
                border-radius: 4px;
            }
            QTabWidget::pane {
                border: 0;
            }
            QScrollArea#tabScrollArea {
                background: transparent;
                border: 0;
            }
            QScrollArea#tabScrollArea > QWidget > QWidget {
                background: transparent;
            }
            QTabBar::tab {
                background: rgba(255, 255, 255, 10);
                border: 1px solid rgba(255, 255, 255, 26);
                border-radius: 8px;
                color: rgba(245, 247, 251, 155);
                min-width: 104px;
                padding: 10px 16px;
                margin-right: 8px;
                font-size: 13px;
                font-weight: 560;
            }
            QTabBar::tab:hover {
                background: rgba(255, 255, 255, 18);
                color: #ffffff;
            }
            QTabBar::tab:selected {
                background: rgba(255, 255, 255, 235);
                color: #090a0d;
                border-color: rgba(255, 255, 255, 245);
            }
            QLineEdit, QKeySequenceEdit, QComboBox {
                background: rgba(255, 255, 255, 13);
                border: 1px solid rgba(255, 255, 255, 34);
                border-radius: 8px;
                color: #ffffff;
                font-size: 15px;
                padding: 10px 12px;
                selection-background-color: rgba(255, 255, 255, 78);
            }
            QLineEdit:hover, QKeySequenceEdit:hover, QComboBox:hover {
                border-color: rgba(255, 255, 255, 70);
                background: rgba(255, 255, 255, 18);
            }
            QLineEdit:focus, QKeySequenceEdit:focus, QComboBox:focus {
                border-color: rgba(255, 255, 255, 170);
                background: rgba(255, 255, 255, 24);
            }
            QComboBox::drop-down {
                border: 0;
                width: 28px;
            }
            QComboBox QAbstractItemView {
                background: #15171d;
                border: 1px solid rgba(255, 255, 255, 44);
                color: #ffffff;
                selection-background-color: rgba(255, 255, 255, 42);
            }
            QPushButton {
                background: rgba(255, 255, 255, 14);
                border: 1px solid rgba(255, 255, 255, 38);
                border-radius: 8px;
                color: #ffffff;
                font-size: 14px;
                font-weight: 620;
                padding: 10px 15px;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 26);
                border-color: rgba(255, 255, 255, 92);
            }
            QPushButton:pressed {
                background: rgba(255, 255, 255, 225);
                color: #050608;
                border-color: rgba(255, 255, 255, 240);
            }
            QPushButton:disabled {
                background: rgba(255, 255, 255, 8);
                border-color: rgba(255, 255, 255, 18);
                color: rgba(255, 255, 255, 95);
            }
            QPushButton[kind="primary"] {
                background: rgba(255, 255, 255, 230);
                border-color: rgba(255, 255, 255, 242);
                color: #050608;
            }
            QPushButton[kind="primary"]:hover {
                background: #ffffff;
            }
            QPushButton[kind="positive"] {
                border-color: rgba(141, 255, 210, 80);
                color: #dfffee;
            }
            QPushButton[kind="warning"] {
                border-color: rgba(255, 185, 110, 85);
                color: #ffe6c9;
            }
            QPushButton[kind="ghost"] {
                background: transparent;
                padding: 6px 8px;
            }
            QCheckBox {
                color: rgba(245, 247, 251, 205);
                font-size: 14px;
                spacing: 9px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
                border-radius: 5px;
                border: 1px solid rgba(255, 255, 255, 62);
                background: rgba(255, 255, 255, 10);
            }
            QCheckBox::indicator:checked {
                background: #ffffff;
                border-color: #ffffff;
            }
            QLabel {
                color: rgba(245, 247, 251, 210);
                font-size: 13px;
            }
            QPlainTextEdit {
                background: rgba(0, 0, 0, 104);
                border: 1px solid rgba(255, 255, 255, 28);
                border-radius: 8px;
                color: rgba(245, 247, 251, 225);
                font-family: "Cascadia Mono", Consolas, monospace;
                font-size: 12px;
                padding: 9px;
            }
            QPlainTextEdit#summaryView {
                background: rgba(255, 255, 255, 10);
                color: rgba(245, 247, 251, 225);
            }
            QTableWidget {
                background: rgba(255, 255, 255, 10);
                border: 1px solid rgba(255, 255, 255, 28);
                border-radius: 8px;
                color: rgba(245, 247, 251, 220);
                gridline-color: rgba(255, 255, 255, 14);
                selection-background-color: rgba(255, 255, 255, 42);
                selection-color: #ffffff;
            }
            QTableWidget::item {
                padding: 7px;
            }
            QTableWidget::item:hover {
                background: rgba(255, 255, 255, 18);
            }
            QHeaderView::section {
                background: rgba(255, 255, 255, 18);
                border: 0;
                border-right: 1px solid rgba(255, 255, 255, 18);
                color: rgba(245, 247, 251, 165);
                font-size: 12px;
                font-weight: 650;
                padding: 8px;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 10px;
                margin: 2px;
            }
            QScrollBar:horizontal {
                background: transparent;
                height: 10px;
                margin: 2px;
            }
            QScrollBar::handle:vertical {
                background: rgba(255, 255, 255, 82);
                border-radius: 5px;
            }
            QScrollBar::handle:vertical:hover {
                background: rgba(255, 255, 255, 135);
            }
            QScrollBar::handle:horizontal {
                background: rgba(255, 255, 255, 82);
                border-radius: 5px;
            }
            QScrollBar::handle:horizontal:hover {
                background: rgba(255, 255, 255, 135);
            }
            """
        )
