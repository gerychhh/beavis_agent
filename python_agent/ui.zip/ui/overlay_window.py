from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QEvent, QPropertyAnimation, Qt, Signal
from PySide6.QtGui import QCursor, QGuiApplication, QKeySequence, QShortcut
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QLineEdit, QVBoxLayout, QWidget

from python_agent.ui.icons import beavis_icon


class OverlayCommandWindow(QWidget):
    submitted = Signal(str)

    def __init__(self) -> None:
        super().__init__(
            None,
            Qt.WindowType.Tool
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint,
        )
        self.setObjectName("overlayWindow")
        self.setWindowIcon(beavis_icon())
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFixedWidth(780)
        self._animations: list[QPropertyAnimation] = []

        frame = QFrame(self)
        frame.setObjectName("overlayFrame")
        frame.setFixedHeight(78)

        self.command_input = QLineEdit(frame)
        self.command_input.setObjectName("overlayInput")
        self.command_input.setPlaceholderText("Команда")
        self.command_input.returnPressed.connect(self._submit)

        layout = QHBoxLayout(frame)
        layout.setContentsMargins(22, 16, 22, 16)
        layout.addWidget(self.command_input)

        root = QHBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.addWidget(frame)

        QShortcut(QKeySequence("Escape"), self, activated=self.hide)
        self.command_input.installEventFilter(self)

        self.setStyleSheet(
            """
            QWidget#overlayWindow {
                background: transparent;
            }
            QFrame#overlayFrame {
                background: rgba(10, 11, 15, 226);
                border: 1px solid rgba(255, 255, 255, 58);
                border-radius: 8px;
            }
            QLineEdit#overlayInput {
                background: rgba(255, 255, 255, 14);
                border: 1px solid rgba(255, 255, 255, 42);
                border-radius: 8px;
                color: #ffffff;
                font-family: "Segoe UI Variable", "Segoe UI", Arial, sans-serif;
                font-size: 21px;
                padding: 10px 13px;
                selection-background-color: rgba(255, 255, 255, 76);
            }
            QLineEdit#overlayInput:hover {
                border-color: rgba(255, 255, 255, 80);
            }
            QLineEdit#overlayInput:focus {
                border-color: rgba(255, 255, 255, 170);
                background: rgba(255, 255, 255, 20);
            }
            """
        )

    def show_centered(self) -> None:
        screen = QGuiApplication.screenAt(QCursor.pos()) or QGuiApplication.primaryScreen()
        if screen is None:
            self.show()
            self.activateWindow()
            self.command_input.setFocus()
            return

        area = screen.availableGeometry()
        self.adjustSize()
        x = area.x() + (area.width() - self.width()) // 2
        y = area.y() + max(40, area.height() // 7)
        self.move(x, y - 14)
        self.command_input.clear()
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        self.command_input.setFocus(Qt.FocusReason.ShortcutFocusReason)
        self._animate_in(x, y)

    def _submit(self) -> None:
        command = self.command_input.text().strip()
        if not command:
            self.hide()
            return

        self.command_input.clear()
        self.hide()
        self.submitted.emit(command)

    def event(self, event: QEvent) -> bool:
        handled = super().event(event)
        if event.type() == QEvent.Type.WindowDeactivate and self.isVisible():
            self.hide()
        return handled

    def eventFilter(self, watched, event: QEvent) -> bool:
        if watched is self.command_input and event.type() == QEvent.Type.FocusOut and self.isVisible():
            self.hide()
        return super().eventFilter(watched, event)

    def mousePressEvent(self, event) -> None:
        if self.childAt(event.position().toPoint()) is not self.command_input:
            self.hide()
            return
        super().mousePressEvent(event)

    def _animate_in(self, x: int, y: int) -> None:
        pos_animation = QPropertyAnimation(self, b"pos", self)
        pos_animation.setDuration(180)
        pos_animation.setStartValue(self.pos())
        pos_animation.setEndValue(self.pos().__class__(x, y))
        pos_animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._start_animation(pos_animation)

        opacity_animation = QPropertyAnimation(self, b"windowOpacity", self)
        opacity_animation.setDuration(150)
        opacity_animation.setStartValue(0.0)
        opacity_animation.setEndValue(1.0)
        opacity_animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._start_animation(opacity_animation)

    def _start_animation(self, animation: QPropertyAnimation) -> None:
        self._animations.append(animation)
        animation.finished.connect(lambda: self._animations.remove(animation) if animation in self._animations else None)
        animation.start()


class VoiceOverlayWindow(QWidget):
    cancelled = Signal()

    def __init__(self) -> None:
        super().__init__(
            None,
            Qt.WindowType.Tool
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint,
        )
        self.setObjectName("voiceOverlayWindow")
        self.setWindowIcon(beavis_icon())
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFixedWidth(520)
        self._animations: list[QPropertyAnimation] = []

        frame = QFrame(self)
        frame.setObjectName("voiceOverlayFrame")

        self.title_label = QLabel("Слушаю", frame)
        self.title_label.setObjectName("voiceOverlayTitle")
        self.detail_label = QLabel("Говори команду", frame)
        self.detail_label.setObjectName("voiceOverlayDetail")
        self.level_label = QLabel("", frame)
        self.level_label.setObjectName("voiceOverlayLevel")
        self.level_label.setFixedHeight(6)

        content = QVBoxLayout(frame)
        content.setContentsMargins(22, 18, 22, 18)
        content.setSpacing(8)
        content.addWidget(self.title_label)
        content.addWidget(self.detail_label)
        content.addWidget(self.level_label)

        root = QHBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.addWidget(frame)

        QShortcut(QKeySequence("Escape"), self, activated=self._cancel)

        self.setStyleSheet(
            """
            QWidget#voiceOverlayWindow {
                background: transparent;
            }
            QFrame#voiceOverlayFrame {
                background: rgba(8, 9, 12, 232);
                border: 1px solid rgba(255, 255, 255, 70);
                border-radius: 12px;
            }
            QLabel#voiceOverlayTitle {
                color: #ffffff;
                font-family: "Segoe UI Variable", "Segoe UI", Arial, sans-serif;
                font-size: 22px;
                font-weight: 650;
            }
            QLabel#voiceOverlayDetail {
                color: rgba(245, 247, 251, 170);
                font-family: "Segoe UI Variable", "Segoe UI", Arial, sans-serif;
                font-size: 13px;
            }
            QLabel#voiceOverlayLevel {
                background: rgba(255, 255, 255, 45);
                border-radius: 3px;
            }
            """
        )

    def show_centered(self, title: str = "Слушаю", detail: str = "Говори команду") -> None:
        self.set_message(title, detail)
        screen = QGuiApplication.screenAt(QCursor.pos()) or QGuiApplication.primaryScreen()
        if screen is None:
            self.show()
            self.activateWindow()
            return

        area = screen.availableGeometry()
        self.adjustSize()
        x = area.x() + (area.width() - self.width()) // 2
        y = area.y() + max(52, area.height() // 6)
        self.move(x, y - 14)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        self._animate_in(x, y)

    def set_message(self, title: str, detail: str = "") -> None:
        self.title_label.setText(title)
        self.detail_label.setText(detail)

    def set_level(self, level: float) -> None:
        opacity = max(0.12, min(1.0, level * 18.0))
        self.level_label.setStyleSheet(
            f"background: rgba(255, 255, 255, {int(45 + opacity * 180)}); border-radius: 3px;"
        )

    def _cancel(self) -> None:
        self.cancelled.emit()
        self.hide()

    def _animate_in(self, x: int, y: int) -> None:
        pos_animation = QPropertyAnimation(self, b"pos", self)
        pos_animation.setDuration(180)
        pos_animation.setStartValue(self.pos())
        pos_animation.setEndValue(self.pos().__class__(x, y))
        pos_animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._start_animation(pos_animation)

        opacity_animation = QPropertyAnimation(self, b"windowOpacity", self)
        opacity_animation.setDuration(150)
        opacity_animation.setStartValue(0.0)
        opacity_animation.setEndValue(1.0)
        opacity_animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._start_animation(opacity_animation)

    def _start_animation(self, animation: QPropertyAnimation) -> None:
        self._animations.append(animation)
        animation.finished.connect(lambda: self._animations.remove(animation) if animation in self._animations else None)
        animation.start()
